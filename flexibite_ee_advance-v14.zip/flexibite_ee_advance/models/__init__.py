# -*- coding: utf-8 -*-
#################################################################################
# Author      : Acespritech Solutions Pvt. Ltd. (<www.acespritech.com>)
# Copyright(c): 2012-Present Acespritech Solutions Pvt. Ltd.
# All Rights Reserved.
#
# This program is copyright property of the author mentioned above.
# You can`t redistribute it and/or modify it.
#
#################################################################################

from . import combo
from . import mrp_bom
from . import pos_order
from . import res_users
from . import kitchen_screen
from . import pos_config
from . import customer_display
from . import pos_payment_method
from . import wallet_management
from . import res_partner
from . import pos_session
from . import account_move
from . import gift_card
from . import gift_voucher
from . import res_config
from . import hr_employee
from . import purchase_order
from . import stock_location
from . import pos_product
from . import remove_product_resion

# vim:expandtab:smartindent:tabstop=4:softtabstop=4:shiftwidth=4:
